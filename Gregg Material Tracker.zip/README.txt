Needed: the amount of materials needed to craft the level of weapon listed above
Held: The amount of materials you currently hold, minus all the materials of the previous, uncrafted, levels of weapon*
The percentage close to Held represent the percantage of materials you currently hold relative to the amount you need to craft that Level of weapon

Colors meanings:
	Cyan = You already crafted the weapon
	Light Green = You have enough materials for that level of weapon
	Orange = you have more than 25% of the materials needed but less than 100%
	Red = you have less than 25% of the materials needed for that level of weapon
	
Add Custom: Will add the number you put in the text box on its left
Set Custom: Will set your current materials as the number you put in the text box on its left

Crafted?: Tick if you have already crafted that level of weapon, untick if you haven't


*Some examples of the "Held:" field
	This is the setup:
	You currently have 51 Metal
	You have already crafted the level 80 weapon
	The level 120 column, Metal row will show "Needed: 20 Held: 51 (100%)" - N.B. Since you already crafted the level 80 weapon, it will not count towards the calculations
	The level 160 column, Metal row will show "Needed: 15 Held: 31 (100%)" Where the "Held:" field is {Materials You currently have}-{Materials needed to craft all the previous levels of uncrafted weapons} so in our case 51-20
	The level 200 column, Metal row will show "Needed: 65 Held: 16 (24.62%)" Where the "Held:" field is 51-20-15=16


I have put +1, +2, +3, +4 and +6 in case of another double material drop event, wherein you will be able to obtain 4 or 6 materials from one Gregg.

	